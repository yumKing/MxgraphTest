export default {
  getNodeList: (req: any) => {
    return {
      code: 0,
      data: {},
    };
  },
};
