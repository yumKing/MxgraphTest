<template>
  <div class="graph-test">
    <div class="title">{{ title }}</div>

    <div class="mxgraph" style="position: relative; overflow: auto">
      &lt;mxGraphModel&gt;&lt;root&gt;&lt;mxCell id="0"/&gt;&lt;mxCell id="1"
      parent="0"/&gt;&lt;mxCell id="2" vertex="1" parent="1" value="Interval
      1"&gt;&lt;mxGeometry x="380" y="0" width="140" height="30"
      as="geometry"/&gt;&lt;/mxCell&gt;&lt;mxCell id="3" vertex="1" parent="1"
      value="Interval 2"&gt;&lt;mxGeometry x="200" y="80" width="380"
      height="30" as="geometry"/&gt;&lt;/mxCell&gt;&lt;mxCell id="4" vertex="1"
      parent="1" value="Interval 3"&gt;&lt;mxGeometry x="40" y="140" width="260"
      height="30" as="geometry"/&gt;&lt;/mxCell&gt;&lt;mxCell id="5" vertex="1"
      parent="1" value="Interval 4"&gt;&lt;mxGeometry x="120" y="200"
      width="240" height="30" as="geometry"/&gt;&lt;/mxCell&gt;&lt;mxCell id="6"
      vertex="1" parent="1" value="Interval 5"&gt;&lt;mxGeometry x="420" y="260"
      width="80" height="30" as="geometry"/&gt;&lt;/mxCell&gt;&lt;mxCell id="7"
      edge="1" source="2" target="3" parent="1"
      value="Transfer1"&gt;&lt;mxGeometry as="geometry"&gt;&lt;Array
      as="points"&gt;&lt;Object x="420"
      y="60"/&gt;&lt;/Array&gt;&lt;/mxGeometry&gt;&lt;/mxCell&gt;&lt;mxCell
      id="8" edge="1" source="2" target="6" parent="1"
      value=""&gt;&lt;mxGeometry as="geometry" relative="1" y="-30"&gt;&lt;Array
      as="points"&gt;&lt;Object x="600"
      y="60"/&gt;&lt;/Array&gt;&lt;/mxGeometry&gt;&lt;/mxCell&gt;&lt;mxCell
      id="9" edge="1" source="3" target="4" parent="1"
      value="Transfer3"&gt;&lt;mxGeometry as="geometry"&gt;&lt;Array
      as="points"&gt;&lt;Object x="260"
      y="120"/&gt;&lt;/Array&gt;&lt;/mxGeometry&gt;&lt;/mxCell&gt;&lt;mxCell
      id="10" edge="1" source="4" target="5" parent="1"
      value="Transfer4"&gt;&lt;mxGeometry as="geometry"&gt;&lt;Array
      as="points"&gt;&lt;Object x="200"
      y="180"/&gt;&lt;/Array&gt;&lt;/mxGeometry&gt;&lt;/mxCell&gt;&lt;mxCell
      id="11" edge="1" source="4" target="6" parent="1"
      value="Transfer5"&gt;&lt;mxGeometry as="geometry" relative="1"
      y="-10"&gt;&lt;Array as="points"&gt;&lt;Object x="460"
      y="155"/&gt;&lt;/Array&gt;&lt;/mxGeometry&gt;&lt;/mxCell&gt;&lt;/root&gt;&lt;/mxGraphModel&gt;
    </div>
    <div
      class="mxgraph"
      style="
        position: relative;
        background: #eeeeee;
        border: 1px solid gray;
        overflow: auto;
        width: 400px;
        height: 200px;
      "
    >
      &lt;mxGraphModel&gt;&lt;root&gt;&lt;mxCell id="0"/&gt;&lt;mxCell id="1"
      parent="0"/&gt;&lt;mxCell id="2" vertex="1" parent="1" value="Interval
      1"&gt;&lt;mxGeometry x="380" y="0" width="140" height="30"
      as="geometry"/&gt;&lt;/mxCell&gt;&lt;mxCell id="3" vertex="1" parent="1"
      value="Interval 2"&gt;&lt;mxGeometry x="200" y="80" width="380"
      height="30" as="geometry"/&gt;&lt;/mxCell&gt;&lt;mxCell id="4" vertex="1"
      parent="1" value="Interval 3"&gt;&lt;mxGeometry x="40" y="140" width="260"
      height="30" as="geometry"/&gt;&lt;/mxCell&gt;&lt;mxCell id="5" vertex="1"
      parent="1" value="Interval 4"&gt;&lt;mxGeometry x="120" y="200"
      width="240" height="30" as="geometry"/&gt;&lt;/mxCell&gt;&lt;mxCell id="6"
      vertex="1" parent="1" value="Interval 5"&gt;&lt;mxGeometry x="420" y="260"
      width="80" height="30" as="geometry"/&gt;&lt;/mxCell&gt;&lt;mxCell id="7"
      edge="1" source="2" target="3" parent="1"
      value="Transfer1"&gt;&lt;mxGeometry as="geometry"&gt;&lt;Array
      as="points"&gt;&lt;Object x="420"
      y="60"/&gt;&lt;/Array&gt;&lt;/mxGeometry&gt;&lt;/mxCell&gt;&lt;mxCell
      id="8" edge="1" source="2" target="6" parent="1"
      value=""&gt;&lt;mxGeometry as="geometry" relative="1" y="-30"&gt;&lt;Array
      as="points"&gt;&lt;Object x="600"
      y="60"/&gt;&lt;/Array&gt;&lt;/mxGeometry&gt;&lt;/mxCell&gt;&lt;mxCell
      id="9" edge="1" source="3" target="4" parent="1"
      value="Transfer3"&gt;&lt;mxGeometry as="geometry"&gt;&lt;Array
      as="points"&gt;&lt;Object x="260"
      y="120"/&gt;&lt;/Array&gt;&lt;/mxGeometry&gt;&lt;/mxCell&gt;&lt;mxCell
      id="10" edge="1" source="4" target="5" parent="1"
      value="Transfer4"&gt;&lt;mxGeometry as="geometry"&gt;&lt;Array
      as="points"&gt;&lt;Object x="200"
      y="180"/&gt;&lt;/Array&gt;&lt;/mxGeometry&gt;&lt;/mxCell&gt;&lt;mxCell
      id="11" edge="1" source="4" target="6" parent="1"
      value="Transfer5"&gt;&lt;mxGeometry as="geometry" relative="1"
      y="-10"&gt;&lt;Array as="points"&gt;&lt;Object x="460"
      y="155"/&gt;&lt;/Array&gt;&lt;/mxGeometry&gt;&lt;/mxCell&gt;&lt;/root&gt;&lt;/mxGraphModel&gt;
    </div>
    <div
      class="mxgraph"
      style="
        position: relative;
        background: #eeeeee;
        border: 6px solid gray;
        overflow: auto;
        width: 400px;
        height: 200px;
      "
    >
      &lt;mxGraphModel&gt;&lt;root&gt;&lt;mxCell id="0"/&gt;&lt;mxCell id="1"
      parent="0"/&gt;&lt;mxCell id="2" vertex="1" parent="1" value="Interval
      1"&gt;&lt;mxGeometry x="380" y="20" width="140" height="30"
      as="geometry"/&gt;&lt;/mxCell&gt;&lt;mxCell id="3" vertex="1" parent="1"
      value="Interval 2"&gt;&lt;mxGeometry x="200" y="80" width="380"
      height="30" as="geometry"/&gt;&lt;/mxCell&gt;&lt;mxCell id="4" vertex="1"
      parent="1" value="Interval 3"&gt;&lt;mxGeometry x="40" y="140" width="260"
      height="30" as="geometry"/&gt;&lt;/mxCell&gt;&lt;mxCell id="5" vertex="1"
      parent="1" value="Interval 4"&gt;&lt;mxGeometry x="120" y="200"
      width="240" height="30" as="geometry"/&gt;&lt;/mxCell&gt;&lt;mxCell id="6"
      vertex="1" parent="1" value="Interval 5"&gt;&lt;mxGeometry x="420" y="260"
      width="80" height="30" as="geometry"/&gt;&lt;/mxCell&gt;&lt;mxCell id="7"
      edge="1" source="2" target="3" parent="1"
      value="Transfer1"&gt;&lt;mxGeometry as="geometry"&gt;&lt;Array
      as="points"&gt;&lt;Object x="420"
      y="60"/&gt;&lt;/Array&gt;&lt;/mxGeometry&gt;&lt;/mxCell&gt;&lt;mxCell
      id="8" edge="1" source="2" target="6" parent="1"
      value="Transfer2"&gt;&lt;mxGeometry as="geometry" relative="1"
      y="0"&gt;&lt;Array as="points"&gt;&lt;Object x="600"
      y="60"/&gt;&lt;/Array&gt;&lt;/mxGeometry&gt;&lt;/mxCell&gt;&lt;mxCell
      id="9" edge="1" source="3" target="4" parent="1"
      value="Transfer3"&gt;&lt;mxGeometry as="geometry"&gt;&lt;Array
      as="points"&gt;&lt;Object x="260"
      y="120"/&gt;&lt;/Array&gt;&lt;/mxGeometry&gt;&lt;/mxCell&gt;&lt;mxCell
      id="10" edge="1" source="4" target="5" parent="1"
      value="Transfer4"&gt;&lt;mxGeometry as="geometry"&gt;&lt;Array
      as="points"&gt;&lt;Object x="200"
      y="180"/&gt;&lt;/Array&gt;&lt;/mxGeometry&gt;&lt;/mxCell&gt;&lt;mxCell
      id="11" edge="1" source="4" target="6" parent="1"
      value="Transfer5"&gt;&lt;mxGeometry as="geometry" relative="1"
      y="-10"&gt;&lt;Array as="points"&gt;&lt;Object x="460"
      y="155"/&gt;&lt;/Array&gt;&lt;/mxGeometry&gt;&lt;/mxCell&gt;&lt;/root&gt;&lt;/mxGraphModel&gt;
    </div>
    <div
      class="mxgraph"
      style="position: relative; overflow: hidden; border: 6px solid gray"
    >
      &lt;mxGraphModel&gt;&lt;root&gt;&lt;mxCell id="0"/&gt;&lt;mxCell id="1"
      parent="0"/&gt;&lt;mxCell id="2" vertex="1" parent="1" value="Interval
      1"&gt;&lt;mxGeometry x="380" y="20" width="140" height="30"
      as="geometry"/&gt;&lt;/mxCell&gt;&lt;mxCell id="3" vertex="1" parent="1"
      value="Interval 2"&gt;&lt;mxGeometry x="200" y="80" width="380"
      height="30" as="geometry"/&gt;&lt;/mxCell&gt;&lt;mxCell id="4" vertex="1"
      parent="1" value="Interval 3"&gt;&lt;mxGeometry x="40" y="140" width="260"
      height="30" as="geometry"/&gt;&lt;/mxCell&gt;&lt;mxCell id="5" vertex="1"
      parent="1" value="Interval 4"&gt;&lt;mxGeometry x="120" y="200"
      width="240" height="30" as="geometry"/&gt;&lt;/mxCell&gt;&lt;mxCell id="6"
      vertex="1" parent="1" value="Interval 5"&gt;&lt;mxGeometry x="420" y="260"
      width="80" height="30" as="geometry"/&gt;&lt;/mxCell&gt;&lt;mxCell id="7"
      edge="1" source="2" target="3" parent="1"
      value="Transfer1"&gt;&lt;mxGeometry as="geometry"&gt;&lt;Array
      as="points"&gt;&lt;Object x="420"
      y="60"/&gt;&lt;/Array&gt;&lt;/mxGeometry&gt;&lt;/mxCell&gt;&lt;mxCell
      id="8" edge="1" source="2" target="6" parent="1"
      value="Transfer2"&gt;&lt;mxGeometry as="geometry" relative="1"
      y="0"&gt;&lt;Array as="points"&gt;&lt;Object x="600"
      y="60"/&gt;&lt;/Array&gt;&lt;/mxGeometry&gt;&lt;/mxCell&gt;&lt;mxCell
      id="9" edge="1" source="3" target="4" parent="1"
      value="Transfer3"&gt;&lt;mxGeometry as="geometry"&gt;&lt;Array
      as="points"&gt;&lt;Object x="260"
      y="120"/&gt;&lt;/Array&gt;&lt;/mxGeometry&gt;&lt;/mxCell&gt;&lt;mxCell
      id="10" edge="1" source="4" target="5" parent="1"
      value="Transfer4"&gt;&lt;mxGeometry as="geometry"&gt;&lt;Array
      as="points"&gt;&lt;Object x="200"
      y="180"/&gt;&lt;/Array&gt;&lt;/mxGeometry&gt;&lt;/mxCell&gt;&lt;mxCell
      id="11" edge="1" source="4" target="6" parent="1"
      value="Transfer5"&gt;&lt;mxGeometry as="geometry" relative="1"
      y="-10"&gt;&lt;Array as="points"&gt;&lt;Object x="460"
      y="155"/&gt;&lt;/Array&gt;&lt;/mxGeometry&gt;&lt;/mxCell&gt;&lt;/root&gt;&lt;/mxGraphModel&gt;
    </div>

    <!-- <div ref="graphContainer" class="graph"></div> -->
  </div>
</template>

<script lang="ts">
import {
  mxGraph,
  mxClient,
  mxUtils,
  mxEvent,
  mxCodec,
  mxConstants,
} from './util/mxgraph';
import * as mx from 'mxgraph';

import {
  defineComponent,
  nextTick,
  onBeforeUnmount,
  onMounted,
  ref,
} from 'vue';

export default defineComponent({
  name: 'Codec',
  setup() {
    console.log('create Codec');

    const title = ref('XML构建图形');

    onMounted(() => {
      initContainer();
    });

    onBeforeUnmount(() => {
      console.log('destroy Codec');
    });

    const initContainer = () => {
      if (!mxClient.isBrowserSupported()) {
        mxUtils.error('Browser is not supported!', 200, false);
      } else {
        let divs = document.getElementsByClassName('mxgraph');

        for (let i = 0; i < divs.length; i++) {
          everyContainer(divs[i] as HTMLElement);
        }
      }
    };

    const everyContainer = (ele: HTMLElement) => {
      let xml = mxUtils.getTextContent(ele);
      let xmlDocument = mxUtils.parseXml(xml);
      if (
        xmlDocument.documentElement != null &&
        xmlDocument.documentElement.nodeName == 'mxGraphModel'
      ) {
        let decoder = new mxCodec(xmlDocument);
        let node = xmlDocument.documentElement;

        ele.innerHTML = '';
        const graph = new mxGraph(ele);
        graph.centerZoom = false;
        graph.setTooltips(false);
        graph.setEnabled(false);

        // 修改 连线 默认样式
        const style = graph.getStylesheet().getDefaultEdgeStyle();
        style[mxConstants.STYLE_EDGE] = mxConstants.EDGESTYLE_ELBOW;

        graph.panningHandler.useLeftButtonForPanning = true;
        graph.panningHandler.ignoreCell = true;
        graph.setPanning(true);

        if (ele.style.width == '' && ele.style.height == '') {
          graph.resizeContainer = true;
        } else {
          graph.border = 20;
        }
        decoder.decode(node, graph.getModel());
        graph.resizeContainer = false;

        // 添加放大缩小按钮
        const buttons = document.createElement('div');
        buttons.style.position = 'absolute';
        buttons.style.overflow = 'visible';

        const bs = graph.getBorderSizes();
        buttons.style.top = ele.offsetTop + bs.y + 'px';
        buttons.style.left = ele.offsetLeft + bs.x + 'px';

        let left = 0;
        let bw = 16;
        let bh = 16;

        if (mxClient.IS_QUIRKS) {
          bw -= 1;
          bh -= 1;
        }

        const addButton = (label: any, funct: any) => {
          const btn = document.createElement('div');
          mxUtils.write(btn, label);
          btn.style.position = 'absolute';
          btn.style.backgroundColor = 'transparent';
          btn.style.border = '1px solid gray';
          btn.style.textAlign = 'center';
          btn.style.fontSize = '10px';
          btn.style.cursor = 'hand';
          btn.style.width = bw + 'px';
          btn.style.height = bh + 'px';
          btn.style.left = left + 'px';
          btn.style.top = '0px';

          mxEvent.addListener(btn, 'click', (evt: any) => {
            funct();
            mxEvent.consume(evt);
          });

          left += bw;
          buttons.append(btn);
        };

        addButton('+', () => {
          graph.zoomIn();
        });

        addButton('-', () => {
          graph.zoomOut();
        });

        if (ele.nextSibling != null) {
          ele.parentNode?.insertBefore(buttons, ele.nextSibling);
        } else {
          ele.appendChild(buttons);
        }
      }
    };

    return {
      title,
    };
  },
});
</script>

<style></style>
