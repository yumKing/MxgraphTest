# graph_diagrams

## vue3.x + typescript + mxgraph

## Project setup

```
npm install
```

### Compiles and hot-reloads for development

```
npm run serve
```

### Compiles and minifies for production

```
npm run build
```

### Lints and fixes files

```
npm run lint
```

### Customize configuration

See [Configuration Reference](https://cli.vuejs.org/config/).

### prettier cli

it to make sure that everyone runs Prettier

```
npx prettier --check .
```

format all files with Prettier

```
npx prettier --write .
```
