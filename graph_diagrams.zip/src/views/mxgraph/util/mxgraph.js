import factory from 'mxgraph';
// (window as any)['mxBasePath'] = 'assets/mxgraph';
const mx = factory({
    mxBasePath: 'mxgraph',
});
export default mx;
//# sourceMappingURL=mxgraph.js.map